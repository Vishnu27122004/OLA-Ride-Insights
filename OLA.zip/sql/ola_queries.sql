
SELECT SUM(revenue) AS total_revenue FROM ola_cleaned;
SELECT booking_hour, COUNT(*) FROM ola_cleaned GROUP BY booking_hour;
SELECT vehicle_type, AVG(customer_rating) FROM ola_cleaned GROUP BY vehicle_type;
