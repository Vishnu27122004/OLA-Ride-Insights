
import streamlit as st
import pandas as pd

df = pd.read_csv("ola_cleaned.csv")

st.title("OLA Ride Insights")
st.metric("Total Revenue", df['revenue'].sum())
st.bar_chart(df['booking_status'].value_counts())
