
import pandas as pd
import numpy as np

df = pd.read_csv("ola_rides.csv")
df['booking_date'] = pd.to_datetime(df['booking_date'])
df = df[df['ride_distance_km'] > 0]
df['booking_hour'] = df['booking_date'].dt.hour
df['revenue'] = np.where(df['booking_status']=='Completed', df['fare_amount'], 0)
df['ride_completed_flag'] = np.where(df['booking_status']=='Completed',1,0)
df.to_csv("ola_cleaned.csv", index=False)
print("Cleaning & feature engineering completed")
